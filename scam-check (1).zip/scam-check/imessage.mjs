// Scam Check over iMessage, through Chert.
// Someone texts a screenshot, photo or the message itself to your Chert line; Scam Check replies with a verdict.
// Incoming messages arrive on Chert's event stream (no public URL or tunnel needed).
import { runCheck, toVisionImage } from './engine.mjs';

const BASE = process.env.CHERT_API_BASE || 'https://console.trychert.com/api/v1';

function chertHeaders(json = true) {
  const h = { authorization: `Bearer ${process.env.CHERT_SIGNING_SECRET}` };
  if (process.env.CHERT_TENANT) h['x-chert-tenant'] = process.env.CHERT_TENANT;
  if (json) h['content-type'] = 'application/json';
  return h;
}

export function chertConfigured() {
  return !!process.env.CHERT_SIGNING_SECRET;
}

async function chert(method, path, body) {
  const res = await fetch(BASE + path, { method, headers: chertHeaders(!!body), body: body ? JSON.stringify(body) : undefined, signal: AbortSignal.timeout(20_000) });
  if (!res.ok) throw Object.assign(new Error(`Chert ${method} ${path} -> ${res.status}: ${(await res.text()).slice(0, 300)}`), { status: res.status });
  return res.headers.get('content-type')?.includes('json') ? res.json() : res;
}

/** Send a text by phone number (E.164, e.g. +14085551234). Shared lines only reach verified phones. */
export function sendText(phone, body) {
  return chert('POST', '/send', { phone, body });
}

async function replyInChat(chatId, phone, text) {
  try {
    return await chert('POST', `/chats/${encodeURIComponent(chatId)}/messages`, { message: { parts: [{ type: 'text', value: text }] } });
  } catch (err) {
    if (!phone) throw err;
    console.warn('[imessage] chat reply failed, falling back to /send:', err.message);
    return sendText(phone, text);
  }
}

async function downloadAttachment(id) {
  const res = await fetch(`${BASE}/attachments/${encodeURIComponent(id)}/content`, { headers: chertHeaders(false), signal: AbortSignal.timeout(30_000) });
  if (!res.ok) throw new Error(`attachment ${id} -> ${res.status}`);
  return Buffer.from(await res.arrayBuffer());
}

const HOW_TO = "Hi, I'm Scam Check, an AI helper. Not sure about a text, email or letter? Send me a screenshot or photo of it, or paste the message here, and I'll tell you if it looks like a scam and what to do. Please don't send card, bank or Social Security numbers.";
const seen = new Set();

async function handleEvent(evt) {
  const payload = evt.payload || evt;
  const type = evt.type || payload.event_type;
  if (type && type !== 'message.received') return;
  const data = payload.data || payload;
  const chat = data.chat || {}, message = data.message || {};
  if (!message.id || seen.has(message.id)) return;
  if (message.direction && message.direction !== 'inbound') return;
  seen.add(message.id);

  const chatId = chat.id;
  const phone = message.sender_handle?.handle;
  const parts = message.parts || [];
  const text = parts.filter(p => p.type === 'text').map(p => p.value).join('\n').trim();
  const media = parts.find(p => p.type === 'media' && p.attachment_id);
  console.log(`[imessage] from ${phone || 'unknown'}: ${media ? '[image] ' : ''}${text.slice(0, 80)}`);

  try {
    let input = null;
    if (media) {
      input = await toVisionImage(await downloadAttachment(media.attachment_id));
      if (!input) { await replyInChat(chatId, phone, "I can only read photos and screenshots. Please send a picture, or paste the message text here."); return; }
      input.note = text;
    } else if (text && (text.length >= 25 || /https?:|www\.|\.\w{2,4}\/|\d{3}[\s.-]?\d{3}[\s.-]?\d{4}|\$\d/.test(text))) {
      input = { text };
    } else {
      await replyInChat(chatId, phone, HOW_TO);
      return;
    }
    await replyInChat(chatId, phone, 'Got it. Checking now, this takes about 10 seconds.');
    const result = await runCheck(input, 'imessage');
    let reply = result.imessage || `${result.headline}\n${result.next_step}`;
    if (result.sources?.[0]?.url && !reply.includes(result.sources[0].url)) reply += `\n\nSource: ${result.sources[0].url}`;
    await replyInChat(chatId, phone, reply);
    console.log(`[imessage] replied (${result.verdict}) in ${result.ms} ms`);
  } catch (err) {
    console.error('[imessage] check failed:', err);
    try { await replyInChat(chatId, phone, "Sorry, I couldn't finish that check. Please try sending it again in a minute."); } catch {}
  }
}

/** Listen to Chert's event stream forever, reconnecting with `since`. Falls back to polling if the stream fails. */
export async function listen() {
  if (!chertConfigured()) { console.log('[imessage] CHERT_SIGNING_SECRET not set: iMessage responder is off.'); return; }
  let since = new Date().toISOString();
  let failures = 0;
  console.log('[imessage] listening for texts to your Chert line…');
  while (true) {
    try {
      const res = await fetch(`${BASE}/events/stream?since=${encodeURIComponent(since)}`, { headers: chertHeaders(false) });
      if (!res.ok) throw Object.assign(new Error(`stream ${res.status}: ${(await res.text()).slice(0, 200)}`), { status: res.status });
      failures = 0;
      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buf = '';
      stream: while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buf += decoder.decode(value, { stream: true });
        let idx;
        while ((idx = buf.indexOf('\n\n')) !== -1) {
          const block = buf.slice(0, idx); buf = buf.slice(idx + 2);
          const dataLine = block.split('\n').filter(l => l.startsWith('data:')).map(l => l.slice(5).trim()).join('');
          if (/^event:\s*close/m.test(block)) {
            try { since = JSON.parse(dataLine).reconnect_with_since || since; } catch {}
            break stream;
          }
          if (!dataLine) continue;
          try {
            const evt = JSON.parse(dataLine);
            if (evt.created_at) since = evt.created_at;
            handleEvent(evt); // not awaited: several people can text at once
          } catch (err) { console.error('[imessage] bad event:', err.message); }
        }
      }
    } catch (err) {
      if ([401, 403, 404].includes(err.status)) {
        console.error(`\n[imessage] Chert rejected the iMessage keys: ${err.message.includes('tenant') ? 'unknown or inactive tenant' : 'not authorized'}.`);
        console.error('[imessage] Put the signing secret and tenant slug from the Chert console (API keys) in CHERT_SIGNING_SECRET and CHERT_TENANT');
        console.error('[imessage] in .env.local, then restart with npm run app. iMessage is OFF until then; the web app still works.\n');
        return;
      }
      failures++;
      console.error(`[imessage] stream error (${failures}):`, err.message);
      if (failures >= 3) since = await pollOnce(since);
      await new Promise(r => setTimeout(r, Math.min(2000 * failures, 10_000)));
    }
  }
}

// Fallback: list recent message.received events.
async function pollOnce(since) {
  try {
    const out = await chert('GET', `/events?type=message.received&since=${encodeURIComponent(since)}&limit=50`);
    const events = (out.events || []).sort((a, b) => a.created_at.localeCompare(b.created_at));
    for (const evt of events) { handleEvent(evt); since = evt.created_at; }
  } catch (err) { console.error('[imessage] poll failed:', err.message); }
  return since;
}
