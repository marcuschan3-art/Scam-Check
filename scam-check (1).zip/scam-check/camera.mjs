// Keeps the latest frame from the caller's FaceTime camera and turns it into a JPEG on demand.
// The caller's video arrives as a track named "facetime-remote-video" from participant "chert-bridge-<call id>".
import { RoomEvent, TrackKind, VideoBufferType, VideoRotation, VideoStream } from '@livekit/rtc-node';
import jpeg from 'jpeg-js';

export class CallerCamera {
  latest = null;      // { frame, rotation, at }
  stream = null;
  trackSid = null;

  /** Call BEFORE ctx.connect(), so tracks that arrive after the caller joins are caught. */
  attach(room) {
    this.room = room;
    room.on(RoomEvent.TrackPublished, (publication, participant) => {
      console.log(`[camera] ${participant?.identity} published ${publication?.kind === TrackKind.KIND_VIDEO ? 'video' : 'audio'} "${publication?.name || ''}"`);
    });
    room.on(RoomEvent.TrackSubscribed, (track, publication, participant) => {
      if (track.kind === TrackKind.KIND_VIDEO) {
        console.log(`[camera] caller video subscribed: ${publication?.name || track.sid} from ${participant?.identity}`);
        this.#watch(track);
      }
    });
    room.on(RoomEvent.TrackUnsubscribed, track => {
      if (track.sid === this.trackSid) { console.log('[camera] caller video removed'); this.#stop(); }
    });
    room.on(RoomEvent.TrackMuted, publication => {
      if (publication?.sid === this.trackSid) { console.log('[camera] caller camera muted'); this.latest = null; }
    });
  }

  /** Pick up a video track that was already subscribed before attach() ran. */
  scanExisting() {
    if (!this.room || this.stream) return;
    for (const participant of this.room.remoteParticipants.values()) {
      for (const pub of participant.trackPublications.values()) {
        if (pub.track && pub.track.kind === TrackKind.KIND_VIDEO) { this.#watch(pub.track); return; }
      }
    }
  }

  #watch(track) {
    this.#stop();
    this.trackSid = track.sid;
    const stream = new VideoStream(track);
    this.stream = stream;
    (async () => {
      try {
        let first = true;
        for await (const event of stream) {
          if (this.stream !== stream) return;
          if (first) { first = false; console.log(`[camera] receiving caller video ${event.frame.width}x${event.frame.height}`); }
          this.latest = { frame: event.frame, rotation: event.rotation, at: Date.now() };
        }
      } catch (err) {
        console.log('[camera] video stream ended:', err?.message || err);
      }
    })();
  }

  #stop() {
    const old = this.stream;
    this.stream = null;
    this.trackSid = null;
    this.latest = null;
    if (old) old.cancel().catch(() => {});
  }

  /** True when a frame arrived in the last `maxAgeMs` milliseconds. Never trust an old frame as the current view. */
  hasFreshFrame(maxAgeMs = 3000) {
    return !!this.latest && Date.now() - this.latest.at <= maxAgeMs;
  }

  /** The current camera view as a JPEG Buffer, upright, at most ~1280px on the long side. */
  snapshotJpeg(quality = 82) {
    if (!this.latest) return null;
    const { frame, rotation } = this.latest;
    const rgba = frame.type === VideoBufferType.RGBA ? frame : frame.convert(VideoBufferType.RGBA);
    let img = { data: Buffer.from(rgba.data.buffer, rgba.data.byteOffset, rgba.data.byteLength), width: rgba.width, height: rgba.height };
    img = downscale(img, 1280);
    img = rotate(img, rotation);
    return jpeg.encode(img, quality).data;
  }
}

// Halve the image until its long side fits (fast, good enough for reading text).
function downscale(img, maxSide) {
  while (Math.max(img.width, img.height) > maxSide) {
    const w = img.width >> 1, h = img.height >> 1, out = Buffer.alloc(w * h * 4);
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      const o = (y * w + x) * 4;
      for (let c = 0; c < 4; c++) {
        const i00 = ((2 * y) * img.width + 2 * x) * 4 + c, i01 = i00 + 4, i10 = i00 + img.width * 4, i11 = i10 + 4;
        out[o + c] = (img.data[i00] + img.data[i01] + img.data[i10] + img.data[i11]) >> 2;
      }
    }
    img = { data: out, width: w, height: h };
  }
  return img;
}

// Phones send portrait video with a rotation flag; turn the picture upright so the text reads normally.
function rotate(img, rotation) {
  // If last-snapshot.jpg comes out sideways or upside down, set CAMERA_EXTRA_TURNS=1, 2 or 3 (quarter turns clockwise) in .env.local.
  const base = { [VideoRotation.VIDEO_ROTATION_90]: 1, [VideoRotation.VIDEO_ROTATION_180]: 2, [VideoRotation.VIDEO_ROTATION_270]: 3 }[rotation] || 0;
  const turns = (base + (Number(process.env.CAMERA_EXTRA_TURNS) || 0)) % 4;
  for (let t = 0; t < turns; t++) {
    const { width: w, height: h, data } = img, out = Buffer.alloc(w * h * 4);
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      const src = (y * w + x) * 4, dst = (x * h + (h - 1 - y)) * 4; // 90 degrees clockwise
      out[dst] = data[src]; out[dst + 1] = data[src + 1]; out[dst + 2] = data[src + 2]; out[dst + 3] = data[src + 3];
    }
    img = { data: out, width: h, height: w };
  }
  return img;
}
