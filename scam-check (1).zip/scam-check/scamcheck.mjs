// Scam Check: the instructions, greeting and tools for the FaceTime agent.
// check_what_caller_shows: camera snapshot -> OpenAI vision reads it -> Keenable checks the live web -> verdict.
// search_web: follow-up questions ("is this really my bank's number?").
import { writeFileSync } from 'node:fs';
import { llm } from '@livekit/agents';
import { display } from './face.mjs';
import { keenableSearch, logCheck, readImage } from './engine.mjs';

export const INSTRUCTIONS = `You are Scam Check, a warm, patient AI helper on a FaceTime video call. Most callers are older adults who got a letter, text, email, call or pop-up they are unsure about.

How you talk:
- Speak slowly and simply, in short sentences. No jargon. One idea at a time. Say you are an AI if asked.
- Never ask for, repeat or read aloud passwords, PINs, Social Security numbers, card or account numbers.

Important: you cannot see the caller's camera on your own. The ONLY way to see what they hold up is the check_what_caller_shows tool.
Never give a verdict about something they are showing you without calling check_what_caller_shows first, even if they describe it.
Every time you give a verdict, call show_verdict with it at the same moment, so their screen turns red, amber or green.

How a check goes:
1. Ask them to hold the item up to the camera, close and steady, in good light. If it is hard to read, suggest switching FaceTime to the back camera.
2. As soon as they hold something up or ask about it, say "Hold it right there, I'm reading it now," then call check_what_caller_shows. Call it again whenever they show something new.
3. Give the verdict FIRST, in one sentence: "This looks like a scam," "Be careful, this is suspicious," or "This looks genuine, but let's double-check."
4. Then at most two reasons, in plain words (for example: real agencies never ask for gift cards; the link is not the company's real website).
5. If the web check found something relevant (a warning from the FTC, police, a news story, or the real company's site), mention it in one sentence and name the source.
6. Then one clear next step:
   - Scam: do not call the number, click the link, pay or reply. Throw it away or delete it. If they want to report it: reportfraud.ftc.gov.
   - Suspicious: do not use any contact details on the item; look up the company's real number on your card, statement or official website, and call that.
   - Genuine: still contact them using a number you find yourself, not the one on the item.
   - If they already paid or shared information: call their bank right away using the number on the back of their card, and tell a family member.
7. Ask if they want to check anything else.

If someone is pressuring them right now (on another phone line, waiting at a store to buy gift cards, saying a grandchild is in jail), tell them calmly to stop, hang up on that person, and call a family member using a number they already know.
Never say anything is 100% safe. If you are not sure, say so and recommend the safe next step.
If the tool says it cannot see the camera, ask them to turn on the camera, use FaceTime Video, or hold the item closer. If video still does not work, ask them to read the message aloud (skipping any account or card numbers), then use search_web on the sender, phone number or website, judge it from what they read, and call show_verdict.`;

export const GREETING = 'Greet the caller in one short, friendly sentence: say you are Scam Check, an AI helper, and ask them to hold up the letter, text or email they are unsure about.';

let lastLogged = 0;

export function makeTools(camera) {
  const checkWhatCallerShows = llm.tool({
    name: 'check_what_caller_shows',
    description: 'Look at what the caller is holding up to their camera right now (a letter, text message, email, envelope, pop-up, etc.), read it, check it against the live web, and return what was found so you can give a scam verdict.',
    parameters: {
      type: 'object',
      properties: {
        caller_question: { type: ['string', 'null'], description: 'What the caller asked or said about the item, if anything.' },
      },
      required: ['caller_question'],
      additionalProperties: false,
    },
    execute: async ({ caller_question }) => {
      console.log(`[check] looking at the camera… ${camera.hasFreshFrame() ? 'frame OK' : 'NO CAMERA FRAME (is caller video reaching the agent?)'}`);
      if (!camera.hasFreshFrame()) {
        throw new llm.ToolError("You cannot see the caller's camera right now. Do NOT guess a verdict. Ask them to make sure this is a FaceTime Video call with the camera on and to hold the item up close, or to read the message aloud (skipping account or card numbers). Then use search_web if useful, give the verdict and call show_verdict.");
      }
      display.mode = 'reading';
      const started = Date.now();
      try {
        const jpegBuf = camera.snapshotJpeg();
        try { writeFileSync('last-snapshot.jpg', jpegBuf); } catch { /* debug copy only */ }

        const seen = await readImage(jpegBuf, 'image/jpeg', caller_question);
        console.log(`[check] read in ${Date.now() - started} ms:`, JSON.stringify(seen));
        if (!seen.readable) {
          display.mode = 'idle';
          return { status: 'unreadable', tip: 'Ask them to hold it closer and steadier, with more light, or switch FaceTime to the back camera.' };
        }

        const queries = (seen.search_queries || []).filter(Boolean).slice(0, 3);
        const web_evidence = (await Promise.all(queries.map(q => keenableSearch(q, 3)))).flat().slice(0, 6);
        console.log(`[check] web check done in ${Date.now() - started} ms, ${web_evidence.length} results`);

        lastLogged = Date.now();
        logCheck({ channel: 'facetime', seen, evidence: web_evidence, result: { verdict: seen.preliminary_verdict, headline: seen.what_it_is, reasons: (seen.red_flags || []).slice(0, 2) }, ms: Date.now() - started });
        display.mode = { scam: 'scam', suspicious: 'careful', likely_genuine: 'ok' }[seen.preliminary_verdict] || 'careful';
        display.until = Date.now() + 45_000;
        return {
          status: 'ok',
          what_i_see: seen,
          web_evidence,
          reminder: 'Verdict first, at most two reasons, mention a web source only if it is relevant, then one next step. Keep it short and calm.',
        };
      } catch (err) {
        display.mode = 'idle';
        if (err instanceof llm.ToolError) throw err;
        console.error('[check] failed:', err);
        throw new llm.ToolError('The check failed for a technical reason. Ask them to hold it up again in a moment.');
      }
    },
  });

  const searchWeb = llm.tool({
    name: 'search_web',
    description: "Search the live web to answer a follow-up, e.g. a company's real customer-service phone number, whether a phone number or website is linked to scams, or recent scam warnings.",
    parameters: {
      type: 'object',
      properties: { query: { type: 'string', description: 'A short web search query.' } },
      required: ['query'],
      additionalProperties: false,
    },
    execute: async ({ query }) => {
      const results = await keenableSearch(query, 4);
      return results.length ? { results } : { results: [], note: 'No useful results. Say you could not confirm it online.' };
    },
  });

  const showVerdict = llm.tool({
    name: 'show_verdict',
    description: "Show the verdict on the caller's screen in big letters and color (red SCAM, amber CAREFUL, green LOOKS OK). Call it every time you give a verdict.",
    parameters: {
      type: 'object',
      properties: {
        verdict: { type: 'string', enum: ['scam', 'suspicious', 'likely_genuine'], description: 'The verdict you are giving.' },
        what_it_is: { type: ['string', 'null'], description: 'A few words on what the item is, e.g. "unpaid toll text".' },
      },
      required: ['verdict', 'what_it_is'],
      additionalProperties: false,
    },
    execute: async ({ verdict, what_it_is }) => {
      display.mode = { scam: 'scam', suspicious: 'careful', likely_genuine: 'ok' }[verdict] || 'careful';
      display.until = Date.now() + 45_000;
      console.log(`[verdict] ${verdict} shown on screen${what_it_is ? ` (${what_it_is})` : ''}`);
      if (!lastLogged || Date.now() - lastLogged > 20_000) logCheck({ channel: 'facetime', seen: { what_it_is: what_it_is || '' }, result: { verdict, headline: what_it_is || '' }, ms: 0 });
      return 'Shown on their screen. Now say the verdict out loud if you have not yet.';
    },
  });

  return [checkWhatCallerShows, searchWeb, showVerdict];
}
