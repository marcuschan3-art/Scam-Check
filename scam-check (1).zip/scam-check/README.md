# Scam Check: FaceTime a number, hold up the suspicious thing, get a verdict

A senior FaceTimes Scam Check and holds a letter, text or email up to the camera. The agent reads it,
checks the sender, numbers and links against the live web (Keenable), and says out loud whether
it's a scam, why, and what to do next. The verdict also fills the caller's screen in big letters
and color (red **SCAM**, amber **CAREFUL**, green **LOOKS OK**), so it works for people who are hard of hearing.
There's nothing to install. It runs on FaceTime, which they already use.

Built on Chert's video starter (`chert new --video`). What's added:

| File | What it does |
|---|---|
| `camera.mjs` | Keeps the latest frame from the caller's camera and turns it into an upright JPEG |
| `scamcheck.mjs` | The agent's instructions, plus two tools: `check_what_caller_shows` (vision, then web check, then verdict) and `search_web` |
| `face.mjs` | The agent's on-screen face, with the verdict color and word |
| `agent.mjs` | The starter, wired to subscribe to the caller's video and use the tools |

---

## 1. Before the build (during check-in)

- [ ] A **Mac** (or Linux) with **Node 22.23.2+ or 24.x**: `node -v`
- [ ] **OpenAI API key** with Realtime access and credit on it (the organizers don't supply one)
- [ ] **LiveKit Cloud** project: URL, API key, API secret (Settings → API keys)
- [ ] **Keenable** key: app.keenable.ai/signup, choose "Other" and enter `SOCIALGOOD`
- [ ] **Chert**: project access plus your FaceTime line address. Ask: *"Is caller-camera capture enabled on our line?"*
- [ ] `npm install -g @trychert/facetime@0.1.0-beta.10` then `chert login`
- [ ] An iPhone or iPad to make the FaceTime Video call
- [ ] Print `Scam-Check-demo-props.pdf`, or open it on a second device

## 2. Run it

```sh
cd scam-check
npm install
cp .env.example .env.local && chmod 600 .env.local   # fill in every YOUR_ value
npm run check
npm start                                            # Terminal 1: wait for LiveKit registration
```

Terminal 2, same folder:

```sh
chert doctor --agent "$(grep ^AGENT_NAME .env.local | cut -d= -f2)"
chert dev
```

When `chert dev` says the agent is in the waiting room, place a **FaceTime Video** call to your line.

## 3. First test call (do this before changing anything)

1. The agent greets you within a few seconds. If the call ends silently, check Terminal 1 for OpenAI key or credit errors.
2. Watch Terminal 1 for `[camera] caller video subscribed`. **If it never appears, the line isn't sending your camera.** Ask Chert.
3. Hold up Prop 1. Terminal 1 shows `[check] read in ... ms` and the phone screen turns red with **SCAM**.
4. Open `last-snapshot.jpg` in the folder to see exactly what the model saw. If it's sideways, add `CAMERA_EXTRA_TURNS=1` (or 2 or 3) to `.env.local` and restart both terminals.
5. Hang up, wait for cleanup, call again. A fresh conversation should start.

**Tips:** switch FaceTime to the **back camera** for sharp text, hold the item about 8–12 in away, and use good light.

## 4. Build window plan (11:45–2:15)

| Time | Goal |
|---|---|
| 11:45–12:15 | Get it running on your line and finish the first test call above |
| 12:15–1:00 | Tune the instructions in `scamcheck.mjs` with the scams the partner named at the panel; run all 5 props |
| 1:00–1:30 | Stretch (optional): after a SCAM verdict, text a family member through Chert's iMessage API |
| 1:30–2:15 | **Freeze the code.** Rehearse the demo three times. Record a screen video of one full call as a backup |

Each change needs both terminals restarted. Lines are shared, so book your test slots.

## 5. Demo script (about 2 minutes)

1. **Hook (15 s):** "Successful Aging Solutions told us the scam their seniors fall for most is ___." (Use their answer from the panel.)
2. **Live call (60 s):** FaceTime the line on the projector. Hold up the fake benefits letter (Prop 3). The screen goes red, and the agent explains why it's a scam (asks for SSN and bank account, threat and secrecy, unknown "office") and what to do.
3. **No false alarm (20 s):** hold up the pharmacy text (Prop 5). It comes back green with "still call the number on your label."
4. **Why it'll be used (25 s):** no app or download, just a FaceTime contact; the color verdict works for people who are hard of hearing; it never reads account numbers aloud; Successful Aging Solutions could hand out the number next week.

## 6. If something breaks

| Symptom | Fix |
|---|---|
| Call ends at once / silent | OpenAI key or credits; make sure no second participant publishes audio |
| No `[camera]` line | Use FaceTime **Video** with the camera on; ask Chert whether caller capture is enabled |
| "can't see the caller's camera" | Frame is stale or the camera is muted; hold the item up and ask again |
| OpenAI vision 404/400 | Set `VISION_MODEL` in `.env.local` to a vision model your key has (e.g. `gpt-4.1`, `gpt-4o`) |
| `[keenable] 401` | Wrong or missing `KEENABLE_API_KEY` (verdicts still work, just without web evidence) |
| Old behavior after edits | Restart both terminals |
| Caller video never works | Plan B: FaceTime Audio. The agent asks the caller to read the message aloud and checks it with `search_web` |

---

## 7. Web app + iMessage (`npm run app`)

The same check also works over **iMessage through Chert** and on a **web page**, and every check (FaceTime, iMessage, web) shows up on one **projector page** at `http://localhost:8787/feed`. Put that on the projector during judging.

| File | What it does |
|---|---|
| `engine.mjs` | Shared check: OpenAI reads the photo or text, Keenable searches the live web, then a verdict written for an older adult. Logs each check to `checks.jsonl` for the feed |
| `imessage.mjs` | Listens to Chert's event stream for texts to your line (no public URL or tunnel needed), downloads screenshots and photos (iPhone HEIC converted), and replies with the verdict |
| `server.mjs` + `public/index.html` | The senior web app on port 8787: one question per screen, very large text and buttons, high contrast (WCAG AAA), and verdicts shown with a symbol and a word as well as color. Take or choose a picture, paste a message, video call or text your Chert line, and "Tell my family" (an iMessage sent through Chert) |
| `public/feed.html` | The projector page at `/feed`: your FaceTime and iMessage addresses, today's counts, and every check arriving live |

**Setup:** in `.env.local`, add `ANTHROPIC_API_KEY` (Claude reads the item and writes the verdict; without it the app falls back to `OPENAI_API_KEY`), `KEENABLE_API_KEY`, `CHERT_SIGNING_SECRET` and `CHERT_TENANT` (Chert console → API keys; ask the Chert team if the hackathon project's iMessage keys aren't there), plus `FACETIME_LINE` / `IMESSAGE_LINE` (your line's address) and optionally `FAMILY_PHONE`.

**Run** (a third terminal, same folder; the FaceTime agent can keep running):
```sh
npm run app
```
It prints `http://localhost:8787` and a same-Wi-Fi address for phones, then `[imessage] listening for texts to your Chert line…`.

**Test:** text "hi" to your line (you should get the how-to), then send it a screenshot of Prop 1. You get "Got it. Checking now…" and then the 🔴 SCAM reply; the projector page (`/feed`) shows it with an **iMessage** badge.

**Notes**
- Shared Chert lines only reach **verified phones**, so for the demo, text from a verified phone and send family alerts to a verified phone.
- If texts don't arrive, watch the terminal: `[imessage] stream error` means the Chert keys or tenant are wrong. After 3 errors it switches to polling automatically.
- `checks.jsonl` holds the feed. Delete it before the demo to start clean.

**Demo add-on (30 s):** have a judge text a screenshot to the number while the feed is on the projector. Their check appears live.
