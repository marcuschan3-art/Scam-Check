// The picture your caller sees: one RGBA frame per call to drawFace.
// Scam Check version: the background colour and the big word at the top show the verdict,
// so a caller who is hard of hearing still sees it. Tools set `display.mode`.
export const WIDTH = 640;
export const HEIGHT = 360;
export const FPS = 15;

/** Shared with scamcheck.mjs. mode: 'idle' | 'reading' | 'scam' | 'careful' | 'ok'. `until`: when a verdict goes back to idle. */
export const display = { mode: 'idle', until: 0 };

const MODES = {
  idle:    { bg: [16, 40, 52],   word: 'SCAM CHECK', scale: 6 },
  reading: { bg: [24, 70, 140],  word: 'READING',    scale: 8 },
  scam:    { bg: [200, 28, 28],  word: 'SCAM',       scale: 9 },
  careful: { bg: [225, 140, 0],  word: 'CAREFUL',    scale: 8 },
  ok:      { bg: [20, 135, 70],  word: 'LOOKS OK',   scale: 8 },
};
const FACE = [141, 224, 196], INK = [16, 40, 52], TEXT = [255, 255, 255], ACCENT = [255, 200, 118];

// 5x7 block font, only the letters we need.
const GLYPHS = {
  S: [' ####', '#    ', '#    ', ' ### ', '    #', '    #', '#### '],
  C: [' ### ', '#   #', '#    ', '#    ', '#    ', '#   #', ' ### '],
  A: [' ### ', '#   #', '#   #', '#####', '#   #', '#   #', '#   #'],
  M: ['#   #', '## ##', '# # #', '# # #', '#   #', '#   #', '#   #'],
  H: ['#   #', '#   #', '#   #', '#####', '#   #', '#   #', '#   #'],
  E: ['#####', '#    ', '#    ', '#### ', '#    ', '#    ', '#####'],
  K: ['#   #', '#  # ', '# #  ', '##   ', '# #  ', '#  # ', '#   #'],
  R: ['#### ', '#   #', '#   #', '#### ', '# #  ', '#  # ', '#   #'],
  F: ['#####', '#    ', '#    ', '#### ', '#    ', '#    ', '#    '],
  U: ['#   #', '#   #', '#   #', '#   #', '#   #', '#   #', ' ### '],
  L: ['#    ', '#    ', '#    ', '#    ', '#    ', '#    ', '#####'],
  O: [' ### ', '#   #', '#   #', '#   #', '#   #', '#   #', ' ### '],
  D: ['#### ', '#   #', '#   #', '#   #', '#   #', '#   #', '#### '],
  I: [' ### ', '  #  ', '  #  ', '  #  ', '  #  ', '  #  ', ' ### '],
  N: ['#   #', '##  #', '# # #', '#  ##', '#   #', '#   #', '#   #'],
  G: [' ### ', '#   #', '#    ', '# ###', '#   #', '#   #', ' ### '],
  ' ': ['     ', '     ', '     ', '     ', '     ', '     ', '     '],
};

// Pre-render each mode's word into a mask once.
const MASKS = {};
for (const [mode, { word, scale }] of Object.entries(MODES)) {
  const mask = new Uint8Array(WIDTH * HEIGHT);
  const charW = 6 * scale, totalW = word.length * charW - scale, x0 = Math.round((WIDTH - totalW) / 2), y0 = 16;
  [...word].forEach((ch, n) => {
    const glyph = GLYPHS[ch] || GLYPHS[' '];
    for (let gy = 0; gy < 7; gy++) for (let gx = 0; gx < 5; gx++) {
      if (glyph[gy][gx] !== '#') continue;
      for (let dy = 0; dy < scale; dy++) for (let dx = 0; dx < scale; dx++) {
        const x = x0 + n * charW + gx * scale + dx, y = y0 + gy * scale + dy;
        if (x >= 0 && x < WIDTH && y >= 0 && y < HEIGHT) mask[y * WIDTH + x] = 1;
      }
    }
  });
  MASKS[mode] = mask;
}

/**
 * `tick` counts frames; `speaking` is true while the agent talks, and opens the mouth.
 * Returns WIDTH x HEIGHT pixels, four bytes each: red, green, blue, alpha.
 */
export function drawFace(tick, speaking) {
  if (display.until && Date.now() > display.until) { display.mode = 'idle'; display.until = 0; }
  const mode = MODES[display.mode] ? display.mode : 'idle';
  const BACKGROUND = MODES[mode].bg, mask = MASKS[mode];

  const pixels = new Uint8Array(WIDTH * HEIGHT * 4);
  const cx = WIDTH / 2, cy = HEIGHT / 2 + 40, radius = HEIGHT * 0.3;
  const blink = tick % 60 < 3;                                  // a short blink every four seconds
  const mouth = speaking ? 5 + 12 * Math.abs(Math.sin(tick * 0.8)) : 4;
  const bar = (tick * 6) % (WIDTH - 40);                        // a moving bar, so a frozen picture is easy to spot
  const scanY = mode === 'reading' ? cy - radius + ((tick * 8) % (2 * radius)) : -1; // "scanning" line while reading
  for (let y = 0; y < HEIGHT; y++) {
    for (let x = 0; x < WIDTH; x++) {
      let color = BACKGROUND;
      const inFace = (x - cx) ** 2 + (y - cy) ** 2 < radius ** 2;
      if (inFace) color = FACE;
      const eye = Math.abs(x - (cx - 38)) < 9 || Math.abs(x - (cx + 38)) < 9;
      if (eye && Math.abs(y - (cy - 30)) < (blink ? 2 : 12)) color = INK;
      if (((x - cx) / 40) ** 2 + ((y - (cy + 38)) / mouth) ** 2 < 1) color = INK;
      if (inFace && scanY >= 0 && Math.abs(y - scanY) < 3) color = ACCENT;
      if (mask[y * WIDTH + x]) color = TEXT;
      if (y > HEIGHT - 14 && y < HEIGHT - 6 && x > bar && x < bar + 40) color = ACCENT;
      const i = (y * WIDTH + x) * 4;
      pixels[i] = color[0]; pixels[i + 1] = color[1]; pixels[i + 2] = color[2]; pixels[i + 3] = 255;
    }
  }
  return pixels;
}
