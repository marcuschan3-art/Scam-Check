// The shared Scam Check engine, used by the FaceTime agent, the iMessage responder and the web app.
// read (OpenAI vision or text) -> live web check (Keenable) -> verdict written for an older adult.
import { appendFileSync, existsSync, readFileSync } from 'node:fs';

import jpeg from 'jpeg-js';

// AI provider: Claude when ANTHROPIC_API_KEY is set, otherwise OpenAI.
export const USE_CLAUDE = !!process.env.ANTHROPIC_API_KEY;
const CLAUDE_MODEL = process.env.CLAUDE_MODEL || 'claude-sonnet-5-5';
const VISION_MODEL = process.env.VISION_MODEL || 'gpt-4.1-mini';
const TEXT_MODEL = process.env.TEXT_MODEL || VISION_MODEL;
export const AI_NAME = USE_CLAUDE ? `Claude (${CLAUDE_MODEL})` : process.env.OPENAI_API_KEY ? `OpenAI (${VISION_MODEL})` : null;
const KEENABLE_URL = 'https://api.keenable.ai/v1/search';
const LOG_FILE = new URL('./checks.jsonl', import.meta.url);

export const EXTRACT_PROMPT = `You are a fraud analyst helping an older adult. You are given something they are unsure about (a photo of a letter, a screenshot of a text or email, an envelope, a pop-up, or pasted message text).
Read it carefully and return ONLY a JSON object with these keys:
{
  "readable": boolean,                // false if it is too blurry, dark, far or cut off to judge
  "what_it_is": string,               // e.g. "text message claiming an unpaid toll"
  "claimed_sender": string,
  "asks_for": string,                 // what it wants the person to do
  "payment_method": string,           // gift cards, wire, crypto, Zelle, card, none...
  "pressure_or_threat": string,       // deadlines, threats, secrecy requests, or "none"
  "phone_numbers": string[],
  "links_or_websites": string[],
  "emails": string[],
  "red_flags": string[],              // concrete, short, plain English
  "reassuring_signs": string[],
  "preliminary_verdict": "scam" | "suspicious" | "likely_genuine" | "cant_tell",
  "search_queries": string[]          // up to 3 short web searches that would confirm or rule out a known scam:
                                      // the exact phone number in quotes, the domain, or "<claimed sender> scam <key phrase>"
}
Never copy full account numbers, card numbers, Social Security numbers or passwords: write "[hidden]" instead.`;

const VERDICT_PROMPT = `You write the final answer for Scam Check, for an older adult who asked whether something is a scam.
You get what was read from their item and live web search results. Return ONLY JSON:
{
  "verdict": "scam" | "suspicious" | "likely_genuine" | "cant_tell",
  "headline": string,       // one plain sentence, e.g. "This looks like a scam."
  "reasons": string[],      // at most 2, short, plain words, no jargon
  "next_step": string,      // ONE clear action. Scam: don't call, click, pay or reply; delete it. Suspicious: contact the company using a number from your card, statement or their official website. Genuine: still use a number you find yourself. If they may have already paid or shared info: call your bank using the number on your card and tell a family member.
  "sources": [{"title": string, "url": string}],  // 0-2 web results that genuinely support the verdict (official warnings, the real company's site, news). Never invent URLs.
  "imessage": string        // the whole reply as one iMessage, under 550 characters: start with "🔴 SCAM:", "🟠 BE CAREFUL:" or "🟢 LOOKS OK:" then the headline, the reasons, the next step, and "Report scams at reportfraud.ftc.gov" when it is a scam. Plain text, short lines, warm and calm.
}
Never say anything is 100% safe. Never repeat account, card or Social Security numbers.`;

async function openaiJSON(model, messages) {
  const res = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${process.env.OPENAI_API_KEY}` },
    signal: AbortSignal.timeout(25_000),
    body: JSON.stringify({ model, response_format: { type: 'json_object' }, messages }),
  });
  if (!res.ok) throw new Error(`OpenAI ${res.status}: ${(await res.text()).slice(0, 300)}`);
  const data = await res.json();
  return JSON.parse(data.choices[0].message.content);
}

function parseJSON(text) {
  try { return JSON.parse(text); } catch {}
  const a = text.indexOf('{'), b = text.lastIndexOf('}');
  if (a >= 0 && b > a) return JSON.parse(text.slice(a, b + 1));
  throw new Error('The AI did not return JSON: ' + text.slice(0, 200));
}

// Claude Messages API. content: string, or an array of Claude content blocks.
async function claudeJSON(system, content) {
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' },
    signal: AbortSignal.timeout(40_000),
    body: JSON.stringify({
      model: CLAUDE_MODEL, max_tokens: 1500,
      system: system + '\nRespond with the JSON object only: no code fences, no other text.',
      messages: [{ role: 'user', content }],
    }),
  });
  if (!res.ok) throw new Error(`Claude ${res.status}: ${(await res.text()).slice(0, 300)}`);
  const data = await res.json();
  return parseJSON((data.content || []).filter(b => b.type === 'text').map(b => b.text).join(''));
}

/** Read an image (Buffer) of the suspicious item. mime: image/jpeg | image/png | image/webp | image/gif */
export function readImage(buf, mime = 'image/jpeg', note) {
  if (USE_CLAUDE) return claudeJSON(EXTRACT_PROMPT, [
    { type: 'image', source: { type: 'base64', media_type: mime, data: buf.toString('base64') } },
    { type: 'text', text: `The person said: ${note || '(nothing specific)'}` },
  ]);
  return openaiJSON(VISION_MODEL, [
    { role: 'system', content: EXTRACT_PROMPT },
    { role: 'user', content: [
      { type: 'text', text: `The person said: ${note || '(nothing specific)'}` },
      { type: 'image_url', image_url: { url: `data:${mime};base64,${buf.toString('base64')}`, detail: 'high' } },
    ] },
  ]);
}

/** Read pasted or forwarded message text. */
export function readText(text) {
  if (USE_CLAUDE) return claudeJSON(EXTRACT_PROMPT, `The message they received:\n"""\n${text.slice(0, 6000)}\n"""`);
  return openaiJSON(TEXT_MODEL, [
    { role: 'system', content: EXTRACT_PROMPT },
    { role: 'user', content: `The message they received:\n"""\n${text.slice(0, 6000)}\n"""` },
  ]);
}

/** Keenable live web search. Returns [] on any failure so a check never breaks on search. */
export async function keenableSearch(query, maxResults = 3) {
  if (!process.env.KEENABLE_API_KEY) return [];
  try {
    const res = await fetch(KEENABLE_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-API-Key': process.env.KEENABLE_API_KEY },
      signal: AbortSignal.timeout(6_000),
      body: JSON.stringify({ query, mode: 'realtime', max_results: maxResults, snippet_max_length: 300 }),
    });
    if (!res.ok) { console.error(`[keenable] ${res.status} for "${query}": ${(await res.text()).slice(0, 200)}`); return []; }
    const data = await res.json();
    return (data.results || []).map(r => ({ query, title: r.title, url: r.url, published: r.published_at || null, snippet: r.snippet || '' }));
  } catch (err) {
    console.error(`[keenable] "${query}" failed:`, err?.message || err);
    return [];
  }
}

export async function webEvidence(seen) {
  const queries = (seen.search_queries || []).filter(Boolean).slice(0, 3);
  return (await Promise.all(queries.map(q => keenableSearch(q, 3)))).flat().slice(0, 6);
}

export function writeVerdict(seen, evidence) {
  if (USE_CLAUDE) return claudeJSON(VERDICT_PROMPT, JSON.stringify({ what_was_read: seen, web_search_results: evidence }));
  return openaiJSON(TEXT_MODEL, [
    { role: 'system', content: VERDICT_PROMPT },
    { role: 'user', content: JSON.stringify({ what_was_read: seen, web_search_results: evidence }) },
  ]);
}

/** Full check. input: { image: Buffer, mime } or { text }. Returns a result object (also logged for the live feed). */
export async function runCheck(input, channel = 'web') {
  const started = Date.now();
  const seen = input.image ? await readImage(input.image, input.mime, input.note) : await readText(input.text);
  if (!seen.readable) {
    const result = {
      verdict: 'cant_tell', headline: "I couldn't read that clearly.",
      reasons: [], next_step: 'Try again with a closer, sharper picture in good light, or paste the message text.',
      sources: [], imessage: "I couldn't read that clearly. Please send a closer, sharper photo in good light, or paste the message text here.",
    };
    return logCheck({ channel, seen, evidence: [], result, ms: Date.now() - started });
  }
  const evidence = await webEvidence(seen);
  const result = await writeVerdict(seen, evidence);
  return logCheck({ channel, seen, evidence, result, ms: Date.now() - started });
}

// ---- live feed: every check from FaceTime, iMessage and the web app lands in checks.jsonl ----
export function logCheck({ channel, seen, evidence = [], result, ms }) {
  const entry = {
    at: new Date().toISOString(), channel, ms,
    what_it_is: seen?.what_it_is || '', claimed_sender: seen?.claimed_sender || '',
    red_flags: (seen?.red_flags || []).slice(0, 4),
    verdict: result?.verdict || seen?.preliminary_verdict || 'cant_tell',
    headline: result?.headline || '', reasons: result?.reasons || [], next_step: result?.next_step || '',
    sources: (result?.sources?.length ? result.sources : evidence.slice(0, 2).map(e => ({ title: e.title, url: e.url }))) || [],
    searches: [...new Set(evidence.map(e => e.query))],
  };
  try { appendFileSync(LOG_FILE, JSON.stringify(entry) + '\n'); } catch (err) { console.error('[log]', err.message); }
  return { ...result, ...entry, imessage: result?.imessage };
}

export function recentChecks(n = 20) {
  if (!existsSync(LOG_FILE)) return [];
  const lines = readFileSync(LOG_FILE, 'utf8').trim().split('\n').filter(Boolean);
  return lines.slice(-n).reverse().map(l => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean);
}

// ---- image helpers ----
export function sniffImage(buf) {
  if (!buf || buf.length < 12) return null;
  if (buf[0] === 0xff && buf[1] === 0xd8) return 'image/jpeg';
  if (buf[0] === 0x89 && buf.toString('ascii', 1, 4) === 'PNG') return 'image/png';
  if (buf.toString('ascii', 0, 4) === 'GIF8') return 'image/gif';
  if (buf.toString('ascii', 0, 4) === 'RIFF' && buf.toString('ascii', 8, 12) === 'WEBP') return 'image/webp';
  if (buf.toString('ascii', 4, 8) === 'ftyp' && /^(heic|heix|hevc|hevx|mif1|msf1|heim|heis)$/.test(buf.toString('ascii', 8, 12))) return 'image/heic';
  return null;
}

/** iPhone photos arrive as HEIC, which vision models don't take: convert to JPEG. Big JPEGs are shrunk. */
export async function toVisionImage(buf) {
  let mime = sniffImage(buf);
  if (mime === 'image/heic') {
    const convert = (await import('heic-convert')).default;
    buf = Buffer.from(await convert({ buffer: buf, format: 'JPEG', quality: 0.85 }));
    mime = 'image/jpeg';
  }
  if (mime === 'image/jpeg' && buf.length > 1_500_000) buf = shrinkJpeg(buf, 1600);
  if (mime && buf.length > 3_700_000) return null; // still too big for the AI (e.g. a huge PNG)
  return mime ? { image: buf, mime } : null;
}

function shrinkJpeg(buf, maxSide) {
  try {
    let img = jpeg.decode(buf, { useTArray: true, maxMemoryUsageInMB: 1024 });
    while (Math.max(img.width, img.height) > maxSide) {
      const w = img.width >> 1, h = img.height >> 1, out = new Uint8Array(w * h * 4);
      for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) for (let c = 0; c < 4; c++) {
        const i = ((2 * y) * img.width + 2 * x) * 4 + c, r = img.width * 4;
        out[(y * w + x) * 4 + c] = (img.data[i] + img.data[i + 4] + img.data[i + r] + img.data[i + r + 4]) >> 2;
      }
      img = { data: out, width: w, height: h };
    }
    return Buffer.from(jpeg.encode(img, 85).data);
  } catch (err) { console.error('[image] shrink failed:', err.message); return buf; }
}
