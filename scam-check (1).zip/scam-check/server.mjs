// Scam Check web app + iMessage responder.  Run: npm run app  ->  http://localhost:8787
// Phones on the same Wi-Fi can open http://<your-mac's-IP>:8787 (printed at startup).
import { createServer } from 'node:http';
import { readFileSync } from 'node:fs';
import { networkInterfaces } from 'node:os';
import { AI_NAME, recentChecks, runCheck, toVisionImage } from './engine.mjs';
import { chertConfigured, listen, sendText } from './imessage.mjs';

const PORT = Number(process.env.PORT) || 8787;
const PAGE = new URL('./public/index.html', import.meta.url);
const FEED = new URL('./public/feed.html', import.meta.url);

function send(res, status, body, type = 'application/json') {
  res.writeHead(status, { 'content-type': type, 'cache-control': 'no-store' });
  res.end(type === 'application/json' ? JSON.stringify(body) : body);
}

async function readJSON(req, limit = 25 * 1024 * 1024) {
  const chunks = []; let size = 0;
  for await (const c of req) { size += c.length; if (size > limit) throw Object.assign(new Error('That file is too big. Try a screenshot instead.'), { status: 413 }); chunks.push(c); }
  return JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}');
}

const lastDigits = p => (p ? `•••${String(p).replace(/\D/g, '').slice(-4)}` : null);

const server = createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  try {
    if (req.method === 'GET' && url.pathname === '/') return send(res, 200, readFileSync(PAGE), 'text/html; charset=utf-8');

    if (req.method === 'GET' && url.pathname === '/feed') return send(res, 200, readFileSync(FEED), 'text/html; charset=utf-8');

    if (req.method === 'GET' && url.pathname === '/api/config') {
      return send(res, 200, {
        facetime: process.env.FACETIME_LINE || '',
        imessage: process.env.IMESSAGE_LINE || process.env.FACETIME_LINE || '',
        chert: chertConfigured(),
        keenable: !!process.env.KEENABLE_API_KEY,
        family: lastDigits(process.env.FAMILY_PHONE),
      });
    }

    if (req.method === 'GET' && url.pathname === '/api/recent') return send(res, 200, { checks: recentChecks(Math.min(Number(url.searchParams.get('n')) || 15, 100)) });

    if (req.method === 'POST' && url.pathname === '/api/check') {
      const body = await readJSON(req);
      let input;
      if (body.image) {
        const raw = Buffer.from(String(body.image).replace(/^data:[^,]+,/, ''), 'base64');
        input = await toVisionImage(raw);
        if (!input) return send(res, 400, { error: 'Please use a photo or screenshot (JPEG, PNG or HEIC).' });
        input.note = body.note || '';
      } else if (body.text && body.text.trim().length > 3) {
        input = { text: body.text.trim() };
      } else {
        return send(res, 400, { error: 'Add a photo or paste the message first.' });
      }
      const result = await runCheck(input, 'web');
      return send(res, 200, result);
    }

    if (req.method === 'POST' && url.pathname === '/api/alert-family') {
      if (!chertConfigured()) return send(res, 400, { error: 'Chert iMessage is not set up on this computer.' });
      const body = await readJSON(req, 100_000);
      const phone = (body.phone || process.env.FAMILY_PHONE || '').trim();
      if (!/^\+\d{8,15}$/.test(phone)) return send(res, 400, { error: 'Enter the family phone number with country code, like +14085551234.' });
      const label = { scam: 'SCAM', suspicious: 'BE CAREFUL', likely_genuine: 'LOOKS OK', cant_tell: 'NOT SURE' }[body.verdict] || 'NOT SURE';
      const text = `Scam Check alert: someone in your family just checked a suspicious message. Result: ${label}.\n${body.headline || ''}\nIt might be a good moment to give them a call.`;
      const out = await sendText(phone, text);
      return send(res, 200, { ok: true, status: out?.status || 'sent' });
    }

    send(res, 404, { error: 'Not found' });
  } catch (err) {
    console.error('[web]', err);
    send(res, err.status || 500, { error: err.status ? err.message : 'The check failed. Please try again in a moment.' });
  }
});

server.listen(PORT, '0.0.0.0', () => {
  const ips = Object.values(networkInterfaces()).flat().filter(i => i && i.family === 'IPv4' && !i.internal).map(i => i.address);
  console.log(`\nScam Check web app:  http://localhost:${PORT}`);
  console.log(`  projector feed:     http://localhost:${PORT}/feed`);
  for (const ip of ips) console.log(`  on the same Wi-Fi:  http://${ip}:${PORT}`);
  console.log(`  AI that reads it:    ${AI_NAME || 'MISSING (set ANTHROPIC_API_KEY in .env.local)'}`);
  console.log(`  Keenable web search: ${process.env.KEENABLE_API_KEY ? 'on' : 'OFF (set KEENABLE_API_KEY)'}`);
  console.log(`  Chert iMessage:      ${chertConfigured() ? 'on' : 'OFF (set CHERT_SIGNING_SECRET)'}\n`);
  listen();
});
